import React, { useEffect, useState } from 'react';
import './DoctorData.css';
import DateSection from './AppointmentDetails';

function DoctorData() {
    const [uniqueDays, setUniqueDays] = useState([]);
    const [timeSlotsList, setTimeSlotsList] = useState([]);
    const days = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
    const [scheduleDays, setScheduledDays] = useState([]);
    useEffect(() => {
        const requestOptions = {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ "doctor_id": 2 })
        };
        fetch('https://aartas-qaapp-as.azurewebsites.net/aartas_uat/public/api/doctor', requestOptions)
            .then(response => response.json())
            .then(data => {
                const timeSlotsList = Array.from(data.data[0].timeslots);
                setTimeSlotsList(timeSlotsList);
                const uniqueDay = [...new Map(timeSlotsList.map(item =>
                    [item["date"], item])).values()];
                setUniqueDays(uniqueDay);
                const timePerPatient = data.data[0].time_per_patient;
                const scheduleTimingsResponse = data.data[0].scheduleTimings;
                console.log(`Time Per Patient : ${timePerPatient}`);
                console.log(`Schedule Timings : ${scheduleTimingsResponse}`);
                const scheduledTimings = Object.keys(JSON.parse(data.data[0].scheduleTimings));
                const scheduleDaysList = scheduledTimings.map((day) => {
                    return days[day-1]
                });
                setScheduledDays(scheduleDaysList);
            }); 
    },[])
  return (
    <>
        <div className='main-container'>
            <DateSection uniqueDays={uniqueDays} timeSlotsList={timeSlotsList} scheduleDays={scheduleDays}/>
        </div>
    </>
  )
}

export default DoctorData