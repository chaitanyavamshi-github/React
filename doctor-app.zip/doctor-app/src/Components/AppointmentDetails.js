import React, { useState } from 'react';
import dateFormat from 'dateformat';
import { v4 as uuidv4 } from 'uuid';

function DateSection(props) {
    const [count, setCount] = useState(0);
    const [timeSlots, setTimeSlots] = useState([]);
    const [selectedData, setSelectedData] = useState({
        "date":"",
        "time":"",
        "doctor":"2"
    });
    const [activeDateLink, setActiveDateLink] = useState([]);
    const [activeTimeLink, setActiveTimeLink] = useState([]);
    const dateSelector = (val,date) => {
        setActiveDateLink(date);
        setActiveTimeLink([]);
        let counter = 0;
        const filteredTimes = props.timeSlotsList.filter((item) => {
               return item.date === val;
            }).map((item) => {
                counter = item.booking_status == 0 ? counter+1 : counter;
            return {
                    start_time : item.time_from,
                    status : item.booking_status
            };
        })
        setTimeSlots(filteredTimes);
        selectedData.date = val;
        selectedData.time = "";
        setSelectedData(selectedData);
        setCount(counter);
    }
    const collectData = (time) => {
        setActiveTimeLink(time);
        selectedData.time = time;
        setSelectedData(selectedData);
    }
  return (
    <>
    <div className='dates-container'>
        <div className='date-text'>
            <p>
                <span className='col-xs-12'>Select Date</span> 
            </p>
        </div>
        
        {
            props.uniqueDays.map((item, index) => {
                let formattedDate = dateFormat(item.date,"ddd, mmm dS");
                if(props.scheduleDays.includes((formattedDate).slice(0,3))){
                    const activeBtn = activeDateLink.includes(formattedDate) ? "active" : "inactive";
                if(index<10){
                    return(
                        <button className={`col-lg-2 col-md-2 col-sm-3 col-xs-5 btn-date ${activeBtn}`}
                        key={uuidv4()}
                        onClick={() => dateSelector(item.date,formattedDate)} 
                        date={formattedDate}>
                        {formattedDate}
                        </button>
                    )
                }
                }
            }
            )
        }
    </div>
        <div className='time-container'>
        <div className='time-text'>
            <p>
                <span className='col-xs-12'>{`Select Time Slot `}</span>
            </p>
            <p>
                <span className='count-box col-xs-12'>{`${count} SLOTS AVAILABLE`}</span>
            </p>
        </div>
        {
            timeSlots.map((item, index) => {
                const bookingStatus = !item.status ? "available" : "unavailable";
                const activeBtn = activeTimeLink.includes(item.start_time) ? "active" : "inactive";
                return(
                    <button className={`col-lg-2 col-md-2 col-sm-3 col-xs-5 btn-time ${bookingStatus} ${activeBtn}`}
                onClick={() => collectData(item.start_time)}
                key={uuidv4()}>
                    {item.start_time}
                </button>
                )
            })
        }
        </div>
        <div className='output-container col-xs-12'>
            <p className='h2'>Your Appointment Details</p>
        {
            Object.keys(selectedData).map((key) => {
                const convertedKey = key.toUpperCase();
                return (
                    <p key={uuidv4()}>{convertedKey} : {selectedData[key]}</p>
                )
            })
        }
        </div>
    </>
  )
}

export default DateSection