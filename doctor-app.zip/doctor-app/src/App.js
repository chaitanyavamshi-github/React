import './App.css';
import DoctorData from './Components/DoctorData';

function App() {
  return (
    <>
      <h1 className='text-center'>DOCTOR APPOINTMENT</h1>
      <DoctorData />
    </>
  );
}

export default App;
